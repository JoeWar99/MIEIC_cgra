/**
 * MyParallelogram
 * @constructor
 * @param scene - Reference to MyScene object
 */
class MyParallelogram extends CGFobject {
	constructor(scene) {
		super(scene);
		this.initBuffers();
	}
	initBuffers() {
		this.vertices = [
			0, 0, 0,	//0
			1, 0, 0,	//1
            1,1, 0,	//2
            2,0,0, //3
            2,1,0, //4
			3,1,0, //5
			
			0, 0, 0,	//6
			1, 0, 0,	//7
            1,1, 0,	//8
            2,0,0, //9
            2,1,0, //10
            3,1,0 //11
		];

		//Counter-clockwise reference of vertices
		this.indices = [
		  0,1,2,
		  1,4,2,
		  1,3,4,
		  3,5,4,

		  8,7,6,
		  8,10,7,
		  10,9,7,
		  10,11,9
		];
		this.normals = [
			0,0,-1,
			0,0,-1,
			0,0,-1,
			0,0,-1,
			0,0,-1,
			0,0,-1,
			0,0,1,
			0,0,1,
			0,0,1,
			0,0,1,
			0,0,1,
			0,0,1,
		];
		this.primitiveType = this.scene.gl.TRIANGLES;
		this.initGLBuffers();
	}
}

